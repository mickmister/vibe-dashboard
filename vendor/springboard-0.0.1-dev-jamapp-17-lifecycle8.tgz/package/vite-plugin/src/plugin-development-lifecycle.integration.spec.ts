// @vitest-environment node
import {EventEmitter} from 'node:events';
import {mkdtemp, rm, writeFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {resolve} from 'node:path';
import {afterEach, beforeEach, describe, expect, it, vi} from 'vitest';

const runnerMocks = vi.hoisted(() => ({
    createViteModuleRunner: vi.fn(),
}));

vi.mock('./vite-module-runner.js', () => ({
    createViteModuleRunner: runnerMocks.createViteModuleRunner,
}));

import {springboard} from './index.js';

type EntryHandle = {
    start: ReturnType<typeof vi.fn<() => Promise<void>>>;
    stop: ReturnType<typeof vi.fn<() => Promise<void>>>;
};

type Runner = {
    import: ReturnType<typeof vi.fn<(url: string) => Promise<EntryHandle>>>;
    close: ReturnType<typeof vi.fn<() => void>>;
};

const deferred = () => {
    let resolvePromise!: () => void;
    let rejectPromise!: (error: unknown) => void;
    const promise = new Promise<void>((resolve, reject) => {
        resolvePromise = resolve;
        rejectPromise = reject;
    });
    return {promise, resolve: resolvePromise, reject: rejectPromise};
};

const waitFor = async (predicate: () => boolean) => {
    for (let attempt = 0; attempt < 100; attempt += 1) {
        if (predicate()) return;
        await new Promise((resolve) => setTimeout(resolve, 0));
    }
    throw new Error('Timed out waiting for plugin lifecycle boundary');
};

const makeHarness = () => {
    const httpServer = new EventEmitter();
    const middleware = vi.fn();
    return {
        httpServer,
        server: {
            environments: {ssr: {name: 'ssr'}},
            httpServer,
            middlewares: {use: middleware},
            transformIndexHtml: vi.fn(async (_url: string, html: string) => html),
        },
    };
};

const runConfigureServer = (root: string, harness: ReturnType<typeof makeHarness>) => {
    const previousDirectory = process.cwd();
    process.chdir(root);
    try {
        const plugin = springboard({
            entry: './application.ts',
            platforms: ['node', 'browser'],
            nodeServerPort: 4318,
        }) as {
            config?: (config: object, env: {command: string; mode: string}) => unknown;
            configureServer?: (server: unknown) => void | (() => void | Promise<void>) | Promise<void | (() => void | Promise<void>)>;
        };
        plugin.config?.({}, {command: 'serve', mode: 'test'});
        return Promise.resolve(plugin.configureServer?.(harness.server)).then((postHook) => {
            if (typeof postHook !== 'function') throw new Error('configureServer did not return its post hook');
            return postHook;
        });
    } finally {
        process.chdir(previousDirectory);
    }
};

let temporaryDirectory: string;

beforeEach(async () => {
    temporaryDirectory = await mkdtemp(resolve(tmpdir(), 'springboard-vite-plugin-'));
    await writeFile(resolve(temporaryDirectory, 'application.ts'), 'export {};\n');
    runnerMocks.createViteModuleRunner.mockReset();
});

afterEach(async () => {
    await rm(temporaryDirectory, {recursive: true, force: true});
});

describe('actual Springboard Vite configureServer lifecycle', () => {
    it('serializes startup with concurrent shutdown and disposes exactly once', async () => {
        const startup = deferred();
        const stopped = deferred();
        const entry: EntryHandle = {
            start: vi.fn(async () => startup.promise),
            stop: vi.fn(async () => { stopped.resolve(); }),
        };
        const runner: Runner = {
            import: vi.fn(async () => entry),
            close: vi.fn(),
        };
        runnerMocks.createViteModuleRunner.mockResolvedValue(runner);
        const harness = makeHarness();
        const configuring = runConfigureServer(temporaryDirectory, harness);
        await waitFor(() => entry.start.mock.calls.length === 1);
        harness.httpServer.emit('close');
        harness.httpServer.emit('close');
        expect(entry.stop).not.toHaveBeenCalled();
        startup.resolve();
        const postHook = await configuring;
        expect(harness.server.middlewares.use).not.toHaveBeenCalled();
        await postHook();
        expect(harness.server.middlewares.use).toHaveBeenCalledOnce();

        const htmlMiddleware = harness.server.middlewares.use.mock.calls[0][0] as (
            request: {url?: string},
            response: {statusCode: number; setHeader: ReturnType<typeof vi.fn>; end: ReturnType<typeof vi.fn>},
            next: ReturnType<typeof vi.fn>,
        ) => void;
        const htmlResponse = {statusCode: 0, setHeader: vi.fn(), end: vi.fn()};
        const htmlNext = vi.fn();
        htmlMiddleware({url: '/'}, htmlResponse, htmlNext);
        await waitFor(() => htmlResponse.end.mock.calls.length === 1);
        expect(harness.server.transformIndexHtml).toHaveBeenCalledWith('/', expect.stringContaining('<html'));
        expect(htmlResponse.statusCode).toBe(200);
        expect(htmlResponse.setHeader).toHaveBeenCalledWith('Content-Type', 'text/html');
        expect(htmlResponse.end).toHaveBeenCalledWith(expect.stringContaining('<html'));
        expect(htmlNext).not.toHaveBeenCalled();

        const passThroughResponse = {statusCode: 0, setHeader: vi.fn(), end: vi.fn()};
        const passThroughNext = vi.fn();
        htmlMiddleware({url: '/api/not-html'}, passThroughResponse, passThroughNext);
        expect(passThroughNext).toHaveBeenCalledOnce();
        expect(passThroughResponse.end).not.toHaveBeenCalled();
        expect(harness.server.transformIndexHtml).toHaveBeenCalledOnce();
        await stopped.promise;
        await waitFor(() => runner.close.mock.calls.length === 1);

        expect(runnerMocks.createViteModuleRunner).toHaveBeenCalledOnce();
        expect(runner.import).toHaveBeenCalledOnce();
        expect(entry.start).toHaveBeenCalledOnce();
        expect(entry.stop).toHaveBeenCalledOnce();
        expect(runner.close).toHaveBeenCalledOnce();
    });

    it('propagates startup failure through configureServer and rolls back the runner', async () => {
        const failure = new Error('generated development start failed');
        const entry: EntryHandle = {
            start: vi.fn(async () => { throw failure; }),
            stop: vi.fn(async () => {}),
        };
        const runner: Runner = {
            import: vi.fn(async () => entry),
            close: vi.fn(),
        };
        runnerMocks.createViteModuleRunner.mockResolvedValue(runner);
        const harness = makeHarness();
        await expect(runConfigureServer(temporaryDirectory, harness)).rejects.toBe(failure);
        expect(entry.stop).toHaveBeenCalledOnce();
        expect(runner.close).toHaveBeenCalledOnce();
    });

    it('restarts through a fresh Vite plugin instance after the prior listener disposes', async () => {
        const entries = [0, 1].map((): EntryHandle => ({
            start: vi.fn(async () => {}),
            stop: vi.fn(async () => {}),
        }));
        const runners = entries.map((entry): Runner => ({
            import: vi.fn(async () => entry),
            close: vi.fn(),
        }));
        runnerMocks.createViteModuleRunner
            .mockResolvedValueOnce(runners[0])
            .mockResolvedValueOnce(runners[1]);

        for (let generation = 0; generation < 2; generation += 1) {
            const harness = makeHarness();
            const postHook = await runConfigureServer(temporaryDirectory, harness);
            await postHook();
            harness.httpServer.emit('close');
            await waitFor(() => runners[generation].close.mock.calls.length === 1);
        }

        expect(runnerMocks.createViteModuleRunner).toHaveBeenCalledTimes(2);
        for (let generation = 0; generation < 2; generation += 1) {
            expect(entries[generation].start).toHaveBeenCalledOnce();
            expect(entries[generation].stop).toHaveBeenCalledOnce();
            expect(runners[generation].close).toHaveBeenCalledOnce();
        }
    });
});
