import {describe, expect, it} from 'vitest';
import {generateNodeEntry} from './generate-entry.js';

describe('generated node entry lifecycle boundary', () => {
    it('awaits application readiness and owns production stop/startup rollback', () => {
        const generated = generateNodeEntry('./application.js', 4317);
        expect(generated).toContain('await injectResources({');
        expect(generated).toContain('disposeServerModules = appLifecycle.disposeServerModules');
        expect(generated).toContain("new AggregateError([error, shutdownError], 'Server startup rollback failed')");
        expect(generated).toContain('stopPromise = stopApplication()');
        expect(generated).toContain('await settleNodeApplicationStop([');
    });

    it('routes Vite/HMR disposal through the same exported stop handle', () => {
        const generated = generateNodeEntry('./application.js', 4317);
        expect(generated).toContain('import.meta.hot.dispose(async () => {');
        expect(generated).toContain('await stop();');
        expect(generated).not.toContain('process.once(');
    });
});
