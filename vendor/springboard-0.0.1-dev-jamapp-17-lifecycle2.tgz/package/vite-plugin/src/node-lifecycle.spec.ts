import { describe, expect, it, vi } from 'vitest';
import { settleNodeApplicationStop } from './node-lifecycle.js';

describe('generated node application stop boundary', () => {
  it('attempts module cleanup and server close and aggregates both failures', async () => {
    const cleanup = vi.fn(async () => { throw new Error('cleanup failed'); });
    const close = vi.fn(async () => { throw new Error('close failed'); });
    const failure = await settleNodeApplicationStop([cleanup, close]).then(() => undefined, (error: unknown) => error);
    expect(cleanup).toHaveBeenCalledOnce();
    expect(close).toHaveBeenCalledOnce();
    expect(failure).toBeInstanceOf(AggregateError);
    expect((failure as AggregateError).errors).toHaveLength(2);
  });
});
