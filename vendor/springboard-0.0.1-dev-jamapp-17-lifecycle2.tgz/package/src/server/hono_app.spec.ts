import {initApp} from './hono_app.js';
import {resetServerRegistry, serverRegistry} from './register.js';
import type {KVStore, Springboard} from '../core/index.js';

const makeKVStore = (): KVStore => ({
    get: async () => null,
    set: async () => {},
    getAll: async () => ({}),
});

describe('initApp server module routes', () => {
    beforeEach(() => {
        resetServerRegistry();
    });

    afterEach(() => {
        resetServerRegistry();
    });

    it('serves a registered server module route instead of the SPA fallback', async () => {
        serverRegistry.registerServerModule(({hono}) => {
            hono.post('/dashboard/api/webhooks/github', (c) => c.json({ok: true}));
        });

        const {app, injectResources} = initApp({
            remoteKV: makeKVStore(),
            userAgentKV: makeKVStore(),
            broadcastMessage: () => {},
        });

        await injectResources({
            engine: {} as Springboard,
            getEnvValue: () => 'test',
            serveStaticFile: async (_c, fileName, headers) => new Response(`SPA ${fileName}`, {
                headers,
            }),
        });

        const apiResponse = await app.request('/dashboard/api/webhooks/github', {
            method: 'POST',
        });

        expect(apiResponse.headers.get('content-type')).toContain('application/json');
        expect(await apiResponse.json()).toEqual({ok: true});

        const spaResponse = await app.request('/dashboard/unknown');

        expect(await spaResponse.text()).toBe('SPA index.html');
        expect(spaResponse.headers.get('content-type')).toContain('text/html');
    });

    it('disposes successful modules once in reverse order', async () => {
        const order: string[] = [];
        serverRegistry.registerServerModule(() => () => { order.push('first'); });
        serverRegistry.registerServerModule(async () => async () => { order.push('second'); });
        const lifecycle = initApp({remoteKV: makeKVStore(), userAgentKV: makeKVStore(), broadcastMessage: () => {}});
        await lifecycle.injectResources({engine: {} as Springboard, getEnvValue: () => undefined, serveStaticFile: async () => new Response()});
        await lifecycle.disposeServerModules();
        await lifecycle.disposeServerModules();
        expect(order).toEqual(['second', 'first']);
    });

    it.each([0, 1])('rolls back startup when callback %i fails', async (failureIndex) => {
        const cleaned: number[] = [];
        for (let index = 0; index < 3; index += 1) {
            serverRegistry.registerServerModule(() => {
                if (index === failureIndex) throw new Error(`failure-${index}`);
                return () => { cleaned.push(index); };
            });
        }
        const lifecycle = initApp({remoteKV: makeKVStore(), userAgentKV: makeKVStore(), broadcastMessage: () => {}});
        const failure = await lifecycle.injectResources({engine: {} as Springboard, getEnvValue: () => undefined, serveStaticFile: async () => new Response()})
            .then(() => undefined, (error: unknown) => error);
        expect(failure).toBeInstanceOf(AggregateError);
        expect((failure as AggregateError).errors).toContainEqual(expect.objectContaining({message: `failure-${failureIndex}`}));
        expect(cleaned).toEqual(Array.from({length: failureIndex}, (_, index) => index).reverse());
    });

    it('attempts every cleanup and reports cleanup failures', async () => {
        const cleaned: string[] = [];
        serverRegistry.registerServerModule(() => () => { cleaned.push('first'); });
        serverRegistry.registerServerModule(() => () => { throw new Error('cleanup failed'); });
        serverRegistry.registerServerModule(() => () => { cleaned.push('last'); });
        const lifecycle = initApp({remoteKV: makeKVStore(), userAgentKV: makeKVStore(), broadcastMessage: () => {}});
        await lifecycle.injectResources({engine: {} as Springboard, getEnvValue: () => undefined, serveStaticFile: async () => new Response()});
        await expect(lifecycle.disposeServerModules()).rejects.toThrow('Server module lifecycle failed');
        expect(cleaned).toEqual(['last', 'first']);
    });

    it('keeps application instance cleanup isolated', async () => {
        const calls: string[] = [];
        serverRegistry.registerServerModule(() => () => { calls.push('disposed'); });
        const first = initApp({remoteKV: makeKVStore(), userAgentKV: makeKVStore(), broadcastMessage: () => {}});
        const second = initApp({remoteKV: makeKVStore(), userAgentKV: makeKVStore(), broadcastMessage: () => {}});
        const resources = {engine: {} as Springboard, getEnvValue: () => undefined, serveStaticFile: async () => new Response()};
        await first.injectResources(resources);
        await second.injectResources(resources);
        await first.disposeServerModules();
        expect(calls).toEqual(['disposed']);
        await second.disposeServerModules();
        expect(calls).toEqual(['disposed', 'disposed']);
    });

    it('supports start, stop, and restart on one application instance', async () => {
        let starts = 0;
        let stops = 0;
        serverRegistry.registerServerModule(() => {
            starts += 1;
            return () => { stops += 1; };
        });
        const lifecycle = initApp({remoteKV: makeKVStore(), userAgentKV: makeKVStore(), broadcastMessage: () => {}});
        const resources = {engine: {} as Springboard, getEnvValue: () => undefined, serveStaticFile: async () => new Response()};
        await lifecycle.injectResources(resources);
        await lifecycle.disposeServerModules();
        await lifecycle.injectResources(resources);
        await lifecycle.disposeServerModules();
        expect({starts, stops}).toEqual({starts: 2, stops: 2});
    });

    it('tracks cleanup for modules registered after resource injection', async () => {
        let disposed = 0;
        const lifecycle = initApp({remoteKV: makeKVStore(), userAgentKV: makeKVStore(), broadcastMessage: () => {}});
        await lifecycle.injectResources({engine: {} as Springboard, getEnvValue: () => undefined, serveStaticFile: async () => new Response()});
        serverRegistry.registerServerModule(async () => () => { disposed += 1; });
        await new Promise((resolve) => setTimeout(resolve, 0));
        await lifecycle.disposeServerModules();
        expect(disposed).toBe(1);
    });

    it('waits for concurrent late startup before disposing its cleanup', async () => {
        let release!: () => void;
        let disposed = 0;
        const lifecycle = initApp({remoteKV: makeKVStore(), userAgentKV: makeKVStore(), broadcastMessage: () => {}});
        await lifecycle.injectResources({engine: {} as Springboard, getEnvValue: () => undefined, serveStaticFile: async () => new Response()});
        serverRegistry.registerServerModule(async () => {
            await new Promise<void>((resolve) => { release = resolve; });
            return () => { disposed += 1; };
        });
        const stopping = lifecycle.disposeServerModules();
        release();
        await stopping;
        expect(disposed).toBe(1);
    });

    it('starts the stable catalog for sequential application instances', async () => {
        let starts = 0;
        let stops = 0;
        serverRegistry.registerServerModule(() => { starts += 1; return () => { stops += 1; }; });
        const resources = {engine: {} as Springboard, getEnvValue: () => undefined, serveStaticFile: async () => new Response()};
        for (let index = 0; index < 2; index += 1) {
            const lifecycle = initApp({remoteKV: makeKVStore(), userAgentKV: makeKVStore(), broadcastMessage: () => {}});
            await lifecycle.injectResources(resources);
            await lifecycle.disposeServerModules();
        }
        expect({starts, stops}).toEqual({starts: 2, stops: 2});
    });

    it('fans late registration out once to every live application', async () => {
        let starts = 0;
        let stops = 0;
        const resources = {engine: {} as Springboard, getEnvValue: () => undefined, serveStaticFile: async () => new Response()};
        const first = initApp({remoteKV: makeKVStore(), userAgentKV: makeKVStore(), broadcastMessage: () => {}});
        const second = initApp({remoteKV: makeKVStore(), userAgentKV: makeKVStore(), broadcastMessage: () => {}});
        await Promise.all([first.injectResources(resources), second.injectResources(resources)]);
        serverRegistry.registerServerModule(() => { starts += 1; return () => { stops += 1; }; });
        await Promise.all([first.ready(), second.ready()]);
        await Promise.all([first.disposeServerModules(), second.disposeServerModules()]);
        const future = initApp({remoteKV: makeKVStore(), userAgentKV: makeKVStore(), broadcastMessage: () => {}});
        await future.injectResources(resources);
        await future.disposeServerModules();
        expect({starts, stops}).toEqual({starts: 3, stops: 3});
    });

    it('does not admit registration after disposal into the closed application', async () => {
        let starts = 0;
        let stops = 0;
        const lifecycle = initApp({remoteKV: makeKVStore(), userAgentKV: makeKVStore(), broadcastMessage: () => {}});
        await lifecycle.injectResources({engine: {} as Springboard, getEnvValue: () => undefined, serveStaticFile: async () => new Response()});
        await lifecycle.disposeServerModules();
        serverRegistry.registerServerModule(() => { starts += 1; return () => { stops += 1; }; });
        await lifecycle.disposeServerModules();
        expect({starts, stops}).toEqual({starts: 0, stops: 0});
    });

    it('reports late async startup failure through ready and stop without uncaught errors', async () => {
        let cleaned = 0;
        serverRegistry.registerServerModule(() => () => { cleaned += 1; });
        const lifecycle = initApp({remoteKV: makeKVStore(), userAgentKV: makeKVStore(), broadcastMessage: () => {}});
        await lifecycle.injectResources({engine: {} as Springboard, getEnvValue: () => undefined, serveStaticFile: async () => new Response()});
        serverRegistry.registerServerModule(async () => { throw new Error('late startup failed'); });
        await expect(lifecycle.ready()).rejects.toThrow('Server module lifecycle failed');
        await expect(lifecycle.disposeServerModules()).rejects.toThrow('Server module lifecycle failed');
        expect(cleaned).toBe(1);
    });

    it('shares one exactly-once disposal across concurrent stop calls', async () => {
        let cleaned = 0;
        serverRegistry.registerServerModule(() => async () => { await Promise.resolve(); cleaned += 1; });
        const lifecycle = initApp({remoteKV: makeKVStore(), userAgentKV: makeKVStore(), broadcastMessage: () => {}});
        await lifecycle.injectResources({engine: {} as Springboard, getEnvValue: () => undefined, serveStaticFile: async () => new Response()});
        await Promise.all([lifecycle.disposeServerModules(), lifecycle.disposeServerModules()]);
        expect(cleaned).toBe(1);
    });
});
