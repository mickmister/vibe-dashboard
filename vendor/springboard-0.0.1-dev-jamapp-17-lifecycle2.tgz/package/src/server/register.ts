import type {Context, Hono} from 'hono';
import type {Springboard} from '../core/index.js';

export type ServerModuleAPI = {hono: Hono; hooks: ServerHooks; getEngine: () => Springboard};
export type ServerModuleCleanup = () => void | Promise<void>;
export type ServerModuleCallback = (
    server: ServerModuleAPI,
) => void | ServerModuleCleanup | Promise<void | ServerModuleCleanup>;

type ServerModuleSubscriber = (callback: ServerModuleCallback) => void;
const catalog: ServerModuleCallback[] = [];
const subscribers = new Set<ServerModuleSubscriber>();

const registerServerModule = (callback: ServerModuleCallback): void => {
    catalog.push(callback);
    for (const subscriber of [...subscribers]) subscriber(callback);
};

export type ServerModuleRegistry = {registerServerModule(callback: ServerModuleCallback): void};
export const serverRegistry: ServerModuleRegistry = {registerServerModule};

/** Framework-owned subscription. Snapshot and subscription are established atomically. */
export const subscribeServerModules = (
    subscriber: ServerModuleSubscriber,
): {callbacks: readonly ServerModuleCallback[]; unsubscribe(): void} => {
    subscribers.add(subscriber);
    let active = true;
    return {
        callbacks: [...catalog],
        unsubscribe(): void {
            if (!active) return;
            active = false;
            subscribers.delete(subscriber);
        },
    };
};

export const clearRegisteredServerModules = (): void => { catalog.splice(0); };
export const resetServerRegistry = (): void => {
    clearRegisteredServerModules();
    subscribers.clear();
};

export type RpcMiddleware = (c: Context) => Promise<object>;
type ServerHooks = {registerRpcMiddleware: (cb: RpcMiddleware) => void};
