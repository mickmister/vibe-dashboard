import React, {act, useState} from 'react';
import {render, screen} from '@testing-library/react';
import userEvent from '@testing-library/user-event';

// Temporarily disabled due to Vitest ESM transformation issues with jest-dom
// import '@testing-library/jest-dom';

import {Springboard} from '../../../../core/engine/engine.js';
import {makeMockCoreDependencies, makeMockExtraDependences} from '../../../../core/test/mock_core_dependencies.js';
import springboard from '../../../../core/engine/register.js';
import {vitest} from 'vitest';

import {SpringboardRegistry} from '../../../../core/engine/register.js';
import {createRNWebviewEngine} from '../../entrypoints/platform_react_native_browser.js';
import {Main} from '../../../browser/entrypoints/main.js';
import {createRNMainEngine} from '../../entrypoints/rn_app_springboard_entrypoint.js';

describe.skip('KvRnWebview', () => {
    beforeEach(() => {
        springboard.reset();
    });

    it('should update UI when UserAgent state changes', async () => {
        const mockCoreDepsForRN = makeMockCoreDependencies({store: {}});
        const mockCoreDepsForWebview = makeMockCoreDependencies({store: {}});

        const mockRpcWebview = makeMockRpcInstance('client');
        const mockAsyncStorage = makeMockRNAsyncStorage();
        const mockRemoteRpcForRN = makeMockRpcInstance('client');

        const entrypoint = (sb: SpringboardRegistry | Springboard) => {
            sb.registerModule('Test', {}, async (m) => {
                const myUserAgentState = await m.statesAPI.createUserAgentState('myUserAgentState', {message: 'Hey'});

                const actions = m.createActions({
                    changeValue: async (args: {value: string}) => {
                        myUserAgentState.setState({message: args.value});
                    },
                });

                m.registerRoute('/', {}, () => {
                    const myState = myUserAgentState.useState();

                    const [localState, setLocalState] = useState('');

                    return (
                        <div>
                            <input
                                data-testid={'test-input'}
                                value={localState}
                                onChange={e => setLocalState(e.target.value)}
                            />
                            <button
                                data-testid={'test-submit-action'}
                                onClick={async () => {
                                    await actions.changeValue({value: localState}, {mode: 'local'});
                                }}
                            >
                                Submit action
                            </button>
                            <button
                                data-testid={'test-submit-set-state'}
                                onClick={async () => {
                                    myUserAgentState.setState({message: 'hardcoded'});
                                }}
                            >
                                Submit set state
                            </button>
                            <div data-testid={'test-message-output'}>
                                {myState.message}
                            </div>
                        </div>
                    );
                });
            });
        };

        entrypoint(springboard);

        const onMessageFromRN = (message: string) => {
            (window as any).receiveMessageFromRN(message);
        };

        const onMessageFromWebview = (message: string) => {
            rnEngine.handleMessageFromWebview(message);
        };

        const rnEngine = createRNMainEngine({
            remoteRpc: mockRemoteRpcForRN,
            remoteKv: mockCoreDepsForRN.storage.remote,
            onMessageFromRN,
            asyncStorageDependency: mockAsyncStorage,
        });

        await act(async () => {
            await rnEngine.engine.initialize();
        });

        springboard.reset();

        entrypoint(springboard);

        const webviewEngine = createRNWebviewEngine({
            remoteRpc: mockRpcWebview,
            remoteKv: mockCoreDepsForWebview.storage.remote,
            onMessageFromWebview,
        });

        render(
            <Main
                engine={webviewEngine}
            />
        );

        await act(async () => {
            await new Promise(r => setTimeout(r, 10));
        });
        await new Promise(r => setTimeout(r, 10));

        expect(screen.getByTestId('test-message-output')).toBeInTheDocument();
        expect(screen.getByTestId('test-message-output').textContent).toEqual('Hey');

        await act(async () => {
            await userEvent.type(screen.getByTestId('test-input'), 'new value');
            await userEvent.click(screen.getByTestId('test-submit-action'));
        });

        expect(screen.getByTestId('test-message-output').textContent).toEqual('new value');

        await act(async () => {
            await userEvent.click(screen.getByTestId('test-submit-set-state'));
        });

        expect(screen.getByTestId('test-message-output').textContent).toEqual('hardcoded');
    });
});

const makeMockRpcInstance = (role: 'server' | 'client') => {
    return {
        broadcastRpc: vitest.fn(),
        callRpc: vitest.fn(),
        initialize: vitest.fn().mockResolvedValue(true),
        registerRpc: vitest.fn(),
        role,
    };
};

const makeMockRNAsyncStorage = () => {
    const items: Record<string, string> = {};

    return {
        getAllKeys: async () => Object.keys(items),
        getItem: async (key: string) => items[key],
        setItem: async (key: string, value: string) => {items[key] = value;},
    };
};
