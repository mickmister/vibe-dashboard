// @vitest-environment node
import {build} from 'vite';
import {mkdtemp, readFile, rm, writeFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {dirname, resolve} from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {afterAll, beforeAll, describe, expect, it, vi} from 'vitest';
import {generateNodeEntry} from './utils/generate-entry.js';
import {createDevelopmentNodeLifecycle} from './development-node-lifecycle.js';

type FixtureState = {
  events: string[];
  failModule?: string;
  failInitialize?: boolean;
  cleanupFailures?: string[];
  closeFailure?: boolean;
  hotDispose?: () => Promise<void>;
};

type GeneratedEntry = {
  start: () => Promise<void>;
  stop: () => Promise<void>;
};

const fixtureRoot = resolve(dirname(fileURLToPath(import.meta.url)), 'test-fixtures/generated-entry');
let outputDirectory: string;
let outputFile: string;
let importSequence = 0;

const installState = (overrides: Partial<FixtureState> = {}): FixtureState => {
  const state: FixtureState = {events: [], ...overrides};
  (globalThis as typeof globalThis & {__springboardEntryFixture: FixtureState}).__springboardEntryFixture = state;
  (globalThis as typeof globalThis & {__springboardEntryHot: {dispose: (callback: () => Promise<void>) => void}})
    .__springboardEntryHot = {dispose: (callback) => { state.hotDispose = callback; }};
  return state;
};

const loadGeneratedEntry = async (): Promise<GeneratedEntry> => {
  importSequence += 1;
  return import(`${pathToFileURL(outputFile).href}?fixture=${importSequence}`) as Promise<GeneratedEntry>;
};

const expectCompletedCycle = (events: string[]) => {
  expect(events.slice(0, 5)).toEqual([
    'server:start', 'start:first', 'start:second', 'start:third', 'engine:initialize',
  ]);
  expect(events.slice(5)).toEqual(expect.arrayContaining([
    'server:close', 'cleanup:third', 'cleanup:second', 'cleanup:first',
  ]));
  expect(events).toHaveLength(9);
  expect(events.indexOf('cleanup:third')).toBeLessThan(events.indexOf('cleanup:second'));
  expect(events.indexOf('cleanup:second')).toBeLessThan(events.indexOf('cleanup:first'));
};

beforeAll(async () => {
  outputDirectory = await mkdtemp(resolve(tmpdir(), 'springboard-generated-entry-'));
  const entryFile = resolve(outputDirectory, 'node-entry.ts');
  await writeFile(entryFile, generateNodeEntry(resolve(fixtureRoot, 'application.ts'), 4317));
  await build({
    configFile: false,
    logLevel: 'silent',
    define: {
      'import.meta.env.DEV': 'true',
      'import.meta.env.VITE_USE_WEBSOCKETS_FOR_RPC': 'false',
      'import.meta.hot': 'globalThis.__springboardEntryHot',
    },
    resolve: {alias: {
      '@hono/node-server': resolve(fixtureRoot, 'hono-node-server.ts'),
      'crossws/adapters/node': resolve(fixtureRoot, 'crossws-node.ts'),
      'springboard/vite-plugin': resolve(dirname(fileURLToPath(import.meta.url)), 'node-lifecycle.ts'),
      'springboard/server/hono_app': resolve(fixtureRoot, 'hono-app.ts'),
      'springboard/platforms/node/services/ws_server_core_dependencies': resolve(fixtureRoot, 'dependencies.ts'),
      'springboard/platforms/node/services/node_kvstore_service': resolve(fixtureRoot, 'kv-store.ts'),
      'springboard/core': resolve(fixtureRoot, 'core.ts'),
    }},
    ssr: {noExternal: true},
    build: {
      emptyOutDir: false,
      outDir: resolve(outputDirectory, 'dist'),
      ssr: true,
      rollupOptions: {
        input: entryFile,
        output: {entryFileNames: 'node-entry.mjs', format: 'esm'},
      },
    },
  });
  outputFile = resolve(outputDirectory, 'dist/node-entry.mjs');
  expect(await readFile(outputFile, 'utf8')).toContain('settleNodeApplicationStop');
});

afterAll(async () => {
  await rm(outputDirectory, {recursive: true, force: true});
  delete (globalThis as typeof globalThis & {__springboardEntryFixture?: FixtureState}).__springboardEntryFixture;
  delete (globalThis as typeof globalThis & {__springboardEntryHot?: unknown}).__springboardEntryHot;
});

describe('executable generated production entry lifecycle', () => {
  it('starts, concurrently stops, restarts, and disposes through HMR exactly once in reverse order', async () => {
    const state = installState();
    const entry = await loadGeneratedEntry();

    await entry.start();
    await Promise.all([entry.stop(), entry.stop(), entry.stop()]);
    await entry.start();
    await state.hotDispose?.();

    expectCompletedCycle(state.events.slice(0, 9));
    expectCompletedCycle(state.events.slice(9));
  });

  it('transactionally rolls back module and engine startup failures', async () => {
    const moduleState = installState({failModule: 'second'});
    const moduleEntry = await loadGeneratedEntry();
    await expect(moduleEntry.start()).rejects.toThrow('Server startup rollback failed');
    expect(moduleState.events).toEqual([
      'server:start', 'start:first', 'start:second', 'cleanup:first', 'server:close',
    ]);

    const engineState = installState({failInitialize: true});
    const engineEntry = await loadGeneratedEntry();
    await expect(engineEntry.start()).rejects.toThrow('engine initialize failed');
    expectCompletedCycle(engineState.events);
  });

  it('reports application-cleanup and server-close failures without skipping either boundary', async () => {
    const state = installState({cleanupFailures: ['third', 'first'], closeFailure: true});
    const entry = await loadGeneratedEntry();
    await entry.start();
    const failure = await Promise.all([entry.stop(), entry.stop()])
      .then(() => undefined, (error: unknown) => error);

    expect(failure).toBeInstanceOf(AggregateError);
    const outerErrors = (failure as AggregateError).errors;
    expect(outerErrors).toHaveLength(2);
    expect(outerErrors[0]).toBeInstanceOf(AggregateError);
    expect((outerErrors[0] as AggregateError).errors.map((error) => (error as Error).message))
      .toEqual(['cleanup failed:third', 'cleanup failed:first']);
    expect((outerErrors[1] as Error).message).toBe('server close failed');
    expect(state.events).toContain('cleanup:second');
    expect(state.events).toContain('server:close');
    await entry.stop();
    expect(state.events.filter((event) => event === 'server:close')).toHaveLength(1);
  });
});

describe('executable Vite development lifecycle with the generated handle', () => {
  it('starts, shuts down, restarts, handles HMR, and serializes disposal races', async () => {
    const state = installState();
    let runnersClosed = 0;
    const lifecycle = createDevelopmentNodeLifecycle({
      entryFile: 'generated:node-entry',
      createRunner: async () => ({
        import: async () => loadGeneratedEntry(),
        close: () => { runnersClosed += 1; },
      }),
    });

    await lifecycle.start();
    await Promise.all([lifecycle.stop(), lifecycle.stop()]);
    await lifecycle.restart();
    await state.hotDispose?.();
    await Promise.all([lifecycle.stop(), lifecycle.stop()]);

    expect(runnersClosed).toBe(2);
    expect(state.events.filter((event) => event === 'server:start')).toHaveLength(2);
    expect(state.events.filter((event) => event === 'server:close')).toHaveLength(2);
    expect(state.events.filter((event) => event === 'cleanup:first')).toHaveLength(2);
  });

  it('rolls back a failed generated start and closes its runner exactly once', async () => {
    const state = installState({failModule: 'second'});
    let runnersClosed = 0;
    const lifecycle = createDevelopmentNodeLifecycle({
      entryFile: 'generated:node-entry',
      createRunner: () => ({
        import: async () => loadGeneratedEntry(),
        close: () => { runnersClosed += 1; },
      }),
    });

    await expect(lifecycle.start()).rejects.toThrow('Server startup rollback failed');
    await Promise.all([lifecycle.stop(), lifecycle.stop()]);
    expect(runnersClosed).toBe(1);
    expect(state.events).toEqual([
      'server:start', 'start:first', 'start:second', 'cleanup:first', 'server:close',
    ]);
  });
});
