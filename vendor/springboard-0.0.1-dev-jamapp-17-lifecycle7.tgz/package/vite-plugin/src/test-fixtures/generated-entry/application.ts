// The generated entry must execute a real user entry module. Controlled server
// modules are supplied by the fixture's initApp boundary.
export {};
