const store = {
  get: async () => null,
  set: async () => {},
  getAll: async () => ({}),
};

export const makeWebsocketServerCoreDependenciesWithSqlite = async () => ({
  kvStoreFromKysely: store,
});
