type FixtureState = {
  events: string[];
  failInitialize?: boolean;
};

const state = () => (globalThis as typeof globalThis & {__springboardEntryFixture: FixtureState})
  .__springboardEntryFixture;

export type CoreDependencies = object;

export class Springboard {
  constructor(_dependencies: unknown, _extraDependencies: unknown) {}

  async initialize() {
    state().events.push('engine:initialize');
    if (state().failInitialize) throw new Error('engine initialize failed');
  }
}
