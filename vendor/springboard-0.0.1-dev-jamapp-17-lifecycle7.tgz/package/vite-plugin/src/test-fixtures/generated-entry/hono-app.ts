import {initApp as productionInitApp} from '../../../../src/server/hono_app.js';
import {serverRegistry} from '../../../../src/server/register.js';

type FixtureState = {
  events: string[];
  failModule?: string;
  cleanupFailures?: string[];
};

const state = () => (globalThis as typeof globalThis & {__springboardEntryFixture: FixtureState})
  .__springboardEntryFixture;

for (const name of ['first', 'second', 'third']) {
  serverRegistry.registerServerModule(async () => {
    state().events.push(`start:${name}`);
    if (state().failModule === name) throw new Error(`start failed:${name}`);
    return async () => {
      state().events.push(`cleanup:${name}`);
      if (state().cleanupFailures?.includes(name)) throw new Error(`cleanup failed:${name}`);
    };
  });
}

export const initApp = productionInitApp;
