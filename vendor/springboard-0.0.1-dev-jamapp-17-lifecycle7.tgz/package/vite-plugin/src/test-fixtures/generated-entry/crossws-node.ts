export default function crosswsNode() {
  return {
    publish: () => {},
    handleUpgrade: () => {},
  };
}
