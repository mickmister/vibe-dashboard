export class LocalJsonNodeKVStoreService {
  constructor(_name: string) {}
  get = async () => null;
  set = async () => {};
  getAll = async () => ({});
}
