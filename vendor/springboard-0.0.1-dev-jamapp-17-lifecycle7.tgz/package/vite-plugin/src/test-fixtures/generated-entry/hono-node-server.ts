type FixtureState = {
  events: string[];
  closeFailure?: boolean;
};

const state = () => (globalThis as typeof globalThis & {__springboardEntryFixture: FixtureState})
  .__springboardEntryFixture;

export const serve = (_options: unknown, onListening: (info: {port: number}) => void) => {
  state().events.push('server:start');
  onListening({port: 4317});
  return {
    on: () => {},
    close: (callback: (error?: Error) => void) => {
      state().events.push('server:close');
      queueMicrotask(() => callback(state().closeFailure ? new Error('server close failed') : undefined));
    },
  };
};
