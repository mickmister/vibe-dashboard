import { describe, expect, it, vi } from 'vitest';
import { settleNodeApplicationStop } from './node-lifecycle.js';

describe('generated node application stop boundary', () => {
  it('attempts module cleanup and server close and aggregates both failures', async () => {
    const cleanup = vi.fn(async () => { throw new Error('cleanup failed'); });
    const close = vi.fn(async () => { throw new Error('close failed'); });
    const failure = await settleNodeApplicationStop([cleanup, close]).then(() => undefined, (error: unknown) => error);
    expect(cleanup).toHaveBeenCalledOnce();
    expect(close).toHaveBeenCalledOnce();
    expect(failure).toBeInstanceOf(AggregateError);
    expect((failure as AggregateError).errors).toHaveLength(2);
  });

  it('invokes every operation and preserves failure order for sync and async failures', async () => {
    const calls: string[] = [];
    const first = new Error('first sync');
    const second = new Error('second async');
    const third = new Error('third sync');
    const failure = await settleNodeApplicationStop([
      () => { calls.push('first'); throw first; },
      async () => { calls.push('second'); throw second; },
      () => { calls.push('success'); },
      () => { calls.push('third'); throw third; },
    ]).then(() => undefined, (error: unknown) => error);

    expect(calls).toEqual(['first', 'second', 'success', 'third']);
    expect(failure).toBeInstanceOf(AggregateError);
    expect((failure as AggregateError).errors).toEqual([first, second, third]);
  });

  it('reports a lone synchronous failure after later operations run', async () => {
    const calls: string[] = [];
    const failure = new Error('sync failure');
    await expect(settleNodeApplicationStop([
      () => { calls.push('failure'); throw failure; },
      () => { calls.push('later success'); },
    ])).rejects.toBe(failure);
    expect(calls).toEqual(['failure', 'later success']);
  });
});
