import {settleNodeApplicationStop} from './node-lifecycle.js';

export type DevelopmentModuleRunner = {
  import: (url: string) => Promise<{start?: () => Promise<void>; stop?: () => Promise<void>}>;
  close: () => void | Promise<void>;
};

export type DevelopmentNodeLifecycle = {
  start: () => Promise<void>;
  stop: () => Promise<void>;
  restart: () => Promise<void>;
};

export function createDevelopmentNodeLifecycle(options: {
  entryFile: string;
  createRunner: () => DevelopmentModuleRunner | Promise<DevelopmentModuleRunner>;
}): DevelopmentNodeLifecycle {
  let active: {runner: DevelopmentModuleRunner; module: {stop?: () => Promise<void>}} | undefined;
  let transition = Promise.resolve();

  const stopActive = async () => {
    const current = active;
    active = undefined;
    if (!current) return;
    await settleNodeApplicationStop([
      async () => { await current.module.stop?.(); },
      async () => { await current.runner.close(); },
    ]);
  };

  const startActive = async () => {
    await stopActive();
    const runner = await options.createRunner();
    let entryModule: {start?: () => Promise<void>; stop?: () => Promise<void>} | undefined;
    try {
      entryModule = await runner.import(options.entryFile);
      if (typeof entryModule.start !== 'function') {
        throw new Error('Node entry does not export start()');
      }
      active = {runner, module: entryModule};
      await entryModule.start();
    } catch (error) {
      active = undefined;
      const rollback = await settleNodeApplicationStop([
        async () => { await entryModule?.stop?.(); },
        async () => { await runner.close(); },
      ]).then(() => undefined, (failure: unknown) => failure);
      if (rollback !== undefined) {
        throw new AggregateError([error, rollback], 'Development node startup rollback failed');
      }
      throw error;
    }
  };

  const enqueue = (operation: () => Promise<void>): Promise<void> => {
    const result = transition.then(operation, operation);
    transition = result.then(() => undefined, () => undefined);
    return result;
  };

  return {
    start: () => enqueue(startActive),
    stop: () => enqueue(stopActive),
    restart: () => enqueue(startActive),
  };
}
