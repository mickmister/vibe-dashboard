import type {DevelopmentModuleRunner} from './development-node-lifecycle.js';

export async function createViteModuleRunner(environment: unknown): Promise<DevelopmentModuleRunner> {
    const viteModule = await import('vite') as unknown as {
        createServerModuleRunner: (environment: unknown) => DevelopmentModuleRunner;
    };
    return viteModule.createServerModuleRunner(environment);
}
